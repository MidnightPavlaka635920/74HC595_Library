#include "Shift7Segment.h"

// Segment patterns for 0-9, A-F, '.' (Decimal point), and blank
const byte Shift7Segment::_segmentPatterns[18] = {
    B11111100, // 0
    B01100000, // 1
    B11011010, // 2
    B11110010, // 3
    B01100110, // 4
    B10110110, // 5
    B10111110, // 6
    B11100000, // 7
    B11111110, // 8
    B11110110, // 9
    B11101110, // A
    B11111110, // B
    B10011100, // C
    B01111010, // D
    B10011110, // E
    B10001110, // F
    B00000001, // .
    B00000000  // Blank
};

// Constructor
Shift7Segment::Shift7Segment(int latchPin, int clockPin, int dataPin)
    : _latchPin(latchPin), _clockPin(clockPin), _dataPin(dataPin) {}

// Initialize pins
void Shift7Segment::init() {
    pinMode(_latchPin, OUTPUT);
    pinMode(_clockPin, OUTPUT);
    pinMode(_dataPin, OUTPUT);
}

// Clear the display (turn off all segments)
void Shift7Segment::clearDisplay() {
    digitalWrite(_latchPin, LOW);
    for (int i = 0; i < 4; i++) { // Clear all 4 digits
        shiftOut(_dataPin, _clockPin, LSBFIRST, B00000000);
    }
    digitalWrite(_latchPin, HIGH);
}

// Display a single hexadecimal character (0-F)
void Shift7Segment::displayShowCharacter(int character) {
    digitalWrite(_latchPin, LOW);
    shiftOut(_dataPin, _clockPin, LSBFIRST, _segmentPatterns[character]);
    digitalWrite(_latchPin, HIGH);
}

// Display up to 4 characters and manage decimal points
void Shift7Segment::displayShowNumbers(String number, String dotArr) {
    int length = number.length();

    // Initialize digits and dots
    int digit1 = 17, digit2 = 17, digit3 = 17, digit4 = 17;
    bool dotSetup[] = {false, false, false, false};

    for (int i = 0; i < 4; i++) {
        dotSetup[i] = (dotArr[i] == '.');
    }

    // Parse the number and assign digits
    int numbers = number.toInt();
    switch (length) {
        case 4:
            digit1 = numbers / 1000;            // Thousands place
            digit2 = (numbers % 1000) / 100;    // Hundreds place
            digit3 = (numbers % 100) / 10;      // Tens place
            digit4 = numbers % 10;              // Ones place
            break;
        case 3:
            digit2 = numbers / 100;
            digit3 = (numbers % 100) / 10;
            digit4 = numbers % 10;
            break;
        case 2:
            digit3 = numbers / 10;
            digit4 = numbers % 10;
            break;
        case 1:
            digit4 = numbers % 10;
            break;
    }

    // Shift out the segment patterns
    digitalWrite(_latchPin, LOW);
    shiftOut(_dataPin, _clockPin, LSBFIRST, _segmentPatterns[digit1] | (dotSetup[0] ? B00000001 : 0));
    shiftOut(_dataPin, _clockPin, LSBFIRST, _segmentPatterns[digit2] | (dotSetup[1] ? B00000001 : 0));
    shiftOut(_dataPin, _clockPin, LSBFIRST, _segmentPatterns[digit3] | (dotSetup[2] ? B00000001 : 0));
    shiftOut(_dataPin, _clockPin, LSBFIRST, _segmentPatterns[digit4] | (dotSetup[3] ? B00000001 : 0));
    digitalWrite(_latchPin, HIGH);
}

