#ifndef Shift7Segment_h
#define Shift7Segment_h

#include <Arduino.h>

class Shift7Segment {
public:
    Shift7Segment(int latchPin, int clockPin, int dataPin);

    void init();                               // Initialize pins
    void clearDisplay();                       // Clear the display
    void displayShowCharacter(int character); // Display a single character (0-F)
    void displayShowNumbers(String number, String dotArr); // Display a number with optional dots

private:
    int _latchPin;
    int _clockPin;
    int _dataPin;

    static const byte _segmentPatterns[18]; // Segment patterns for 0-9, A-F, '.', and blank
};

#endif

